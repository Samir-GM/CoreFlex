<?php
session_start();

// Initialize progress array if not exists
if (!isset($_SESSION['progress'])) {
    $_SESSION['progress'] = array();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_entry = array(
        'date' => htmlspecialchars($_POST['date']),
        'weight' => floatval($_POST['weight']),
        'workout' => htmlspecialchars($_POST['workout']),
        'timestamp' => date('Y-m-d H:i:s')
    );
    
    array_unshift($_SESSION['progress'], $new_entry);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CoreFlex - Fitness Training</title>
    <link rel="stylesheet" href="progress.css">
</head>
<body style="background-color:#ee6c41;">

<div class="main-header">
    <h1 class="logo">CoreFlex</h1>
    <a href="membership.php">
        <button class="cta-button">JOIN NOW</button>
    </a>
    <nav>
        <ul class="nav-links">
            <li><a href="index.php">HOME</a></li>
            <li><a href="trainer_and_class.php">CLASSES</a></li>
            <li><a href="about.php">ABOUT US</a></li>
            <li><a href="membership.php">MEMBERSHIP PLANS</a></li>
            <li><a href="https://maps.example.com/coreflex" class="cta-button">FIND A GYM</a></li>
        </ul>
    </nav>
</div>

<div class="container">
    <h1>Gym Progress Tracker</h1>

    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <label for="date">Date:</label>
        <input type="date" id="date" name="date" required 
               value="<?php echo date('Y-m-d'); ?>">

        <label for="weight">Weight (kg):</label>
        <input type="number" id="weight" name="weight" min="0" step="0.1" required>

        <label for="workout">Workout Summary:</label>
        <textarea id="workout" name="workout" rows="3" 
                  placeholder="e.g. Chest and triceps, cardio" required></textarea>

        <button type="submit">Add Progress</button>
    </form>

    <h2>Your Progress</h2>
    <div id="progressList">
        <?php foreach ($_SESSION['progress'] as $entry): ?>
            <div class="progress-entry">
                <h3><?php echo date('F j, Y', strtotime($entry['date'])); ?></h3>
                <p><strong>Weight:</strong> <?php echo $entry['weight']; ?> kg</p>
                <p><strong>Workout:</strong> <?php echo $entry['workout']; ?></p>
                <small>Recorded: <?php echo $entry['timestamp']; ?></small>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="progress.js"></script>
</body>
</html>