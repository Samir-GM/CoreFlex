<?php
// index.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CoreFlex - Membership Plans</title>
    <link rel="stylesheet" href="site.css">
</head>
<body style="background-color:#ee6c41;">

<div class="main-header">
    <h1 class="logo">CoreFlex</h1>
    <a href="membership.php">
        <button class="cta-button">JOIN NOW</button>
    </a>
    <nav>
     <ul class="nav-links">
         <li><a href="index.php">HOME</a></li>
         <li><a href="trainer and class.php">CLASSES</a></li>
         <li><a href="About.php">Aboutus</a></li>
         <li><a href="membership.php">membership-plans</a></li>
         <li><a href="https://www.google.com.au/maps/place/Coreflex/@-37.9107394,144.7583537,17z/data=!3m1!4b1!4m6!3m5!1s0x6ad687d78be6e053:0x7d46bb168ad75b7c!8m2!3d-37.9107394!4d144.7609286!16s%2Fg%2F11c2lbqf7v?entry=ttu&g_ep=EgoyMDI1MDQyMy4wIKXMDSoASAFQAw%3D%3D" class="cta-button">FIND A GYM</a></li>
     </ul>
 </nav>
</div>
     <main class="features-container">
   
     <div class="feature-card">
        <a href="trainer and class.html"class="nav-links">
        <h3 >TRAINING CLASSES</h3>
        <p>Transform your fitness with CoreFlex: Strengthen core, enhance flexibility, and improve mobility in quick, adaptable sessions. Perfect for all levels. Start now-fed! stronger, move freely!</p>
</a>
</div>

    <div class="feature-card">
        <a class="nav-links"href="gymprogress.html"><h3>TRACK GYM PROGRESS</h3>
        <p>Track your fitness journey with CoreFlex: Monitor strength, flexibility, and progress through measurable</p>
   </a> </div>

    <div class="feature-card">
        <h3>CALCULATE CALORIE INTAKE</h3>
        <p>Track calorie intake with CoreFlex: Balance activities, optimize workers, and hit goals. Monitor progress, feel marrier, achieve results-start today!</p>
    </div>

</main>
</body>

<section class="section" id="team">
    <h2 class="section-title">Meet The Team</h2>
    <div class="team-section">
        <div class="team-member">
            <img src="oscar.jpg" alt="Oscar">
            <h3>Oscar</h3>
            <p>Tech & Operations</p>
        </div>
        <div class="team-member">
            <img src="samir.jpg" alt="Samir">
            <h3>Samir</h3>
            <p>Head Trainer</p>
        </div>
        <div class="team-member">
            <img src="mahima.jpg" alt="Mahima">
            <h3>Mahima</h3>
            <p>Community Manager</p>
        </div>
    </div>
</section>

<footer>
    <p>Contact us: team@corflex.com | Student Project by Oscar, Samir & Mahima</p>
    <p>© 2023 Corflex Gym. All rights reserved.</p>
</footer>
</html>