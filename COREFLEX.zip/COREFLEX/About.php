<?php
// Initialize session if needed
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CoreFlex - Fitness Training</title>
    <link rel="stylesheet" href="site.css">
</head>
<body style="background-color:#ee6c41;">

<div class="main-header">
    <h1 class="logo">CoreFlex</h1>
    <a href="membership.php">
        <button class="cta-button">JOIN NOW</button>
    </a>
    <nav>
        <ul class="nav-links">
            <li><a href="index.php">HOME</a></li>
            <li><a href="trainer_and_class.php">CLASSES</a></li>
            <li><a href="about.php">ABOUT US</a></li>
            <li><a href="membership.php">MEMBERSHIP PLANS</a></li>
            <li><a href="https://maps.example.com/coreflex" class="cta-button">FIND A GYM</a></li>
        </ul>
    </nav>
</div>

<section class="hero" id="home">
    <div class="hero-content">
        <h1>Fuel Your Fitness Journey</h1>
        <p class="hero-text">Student-powered gym community offering affordable access and expert guidance</p>
        <a href="membership.php" class="cta-button">Start Free Trial</a>
    </div>
</section>

<section class="section" id="about">
    <h2 class="section-title">Why Choose Corflex?</h2>
    <div class="features">
        <?php
        $features = [
            [
                'title' => 'Student Pricing',
                'desc' => 'Affordable memberships designed for student budgets'
            ],
            [
                'title' => 'Expert Trainers',
                'desc' => 'Certified coaches and personalized workout plans'
            ],
            [
                'title' => '24/7 Access',
                'desc' => 'Virtual and in-person training whenever youre ready'
            ]
        ];
        
        foreach ($features as $feature) {
            echo '<div class="feature-card">';
            echo '<h3>' . $feature['title'] . '</h3>';
            echo '<p>' . $feature['desc'] . '</p>';
            echo '</div>';
        }
         ?>
    </div>
</section>

<section class="section" id="team">
    <h2 class="section-title">Meet The Team</h2>
    <div class="team-section">
        <?php
        $teamMembers = [
            ['name' => 'Oscar', 'role' => 'Tech & Operations', 'img' => 'oscar.jpg'],
            ['name' => 'Samir', 'role' => 'Head Trainer', 'img' => 'samir.jpg'],
            ['name' => 'Mahima', 'role' => 'Community Manager', 'img' => 'mahima.jpg']
        ];
        
        foreach ($teamMembers as $member) {
            echo '<div class="team-member">';
            echo '<img src="' . $member['img'] . '" alt="' . $member['name'] . '">';
            echo '<h3>' . $member['name'] . '</h3>';
            echo '<p>' . $member['role'] . '</p>';
            echo '</div>';
        }
        ?>
    </div>
</section>

<footer>
    <p>Contact us: team@corflex.com | Student Project by Oscar, Samir & Mahima</p>
    <p>&copy; <?php echo date('Y'); ?> Corflex Gym. All rights reserved.</p>
</footer>

</body>
</html>