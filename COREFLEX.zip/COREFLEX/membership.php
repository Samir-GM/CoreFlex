<?php
// membership.php - Single file version
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CoreFlex - Membership Plans</title>
    <link rel="stylesheet" href="class.css">
</head>
<body style="background-color:#ee6c41;">

<div class="main-header">
    <h1 class="logo">CoreFlex</h1>
    <a href="membership.php">
        <button class="cta-button">JOIN NOW</button>
    </a>
    <nav>
        <ul class="nav-links">
            <li><a href="index.php">HOME</a></li>
            <li><a href="trainer_and_class.php">CLASSES</a></li>
            <li><a href="about.php">ABOUT US</a></li>
            <li><a href="membership.php">MEMBERSHIP PLANS</a></li>
            <li><a href="https://www.google.com.au/maps/place/Coreflex/" class="cta-button">FIND A GYM</a></li>
        </ul>
    </nav>
</div>

<div class="hero-section">
    <h2>Transform Your Fitness Journey</h2>
    <p>Choose the perfect membership plan for your goals</p>
</div>

<div class="membership-plans">
    <?php
    // Membership plans data array
    $plans = [
        [
            'title' => 'BASIC',
            'price' => 29,
            'features' => [
                'Access to main gym area',
                'Free fitness assessment',
                'Basic workout tracking'
            ]
        ],
        [
            'title' => 'PREMIUM',
            'price' => 49,
            'features' => [
                'All Basic features',
                'Group classes included',
                'Advanced progress tracking',
                'Nutrition planning'
            ]
        ],
        [
            'title' => 'PRO',
            'price' => 79,
            'features' => [
                'All Premium features',
                'Personal trainer sessions',
                'VIP class booking',
                'Premium amenities'
            ]
        ]
    ];

    // Generate plan cards dynamically
    foreach ($plans as $plan) {
        echo '<div class="plan-card">';
        echo '<h3>' . $plan['title'] . '</h3>';
        echo '<div class="price">$' . $plan['price'] . '<span>/mo</span></div>';
        echo '<ul>';
        foreach ($plan['features'] as $feature) {
            echo '<li>' . $feature . '</li>';
        }
        echo '</ul>';
        echo '<a href="#" class="cta-button">Get Started</a>';
        echo '</div>';
    }
    ?>
</div>

<section class="section" id="team">
    <h2 class="section-title">Meet The Team</h2>
    <div class="team-section">
        <?php
        $teamMembers = [
            ['name' => 'Oscar', 'role' => 'Tech & Operations', 'image' => 'oscar.jpg'],
            ['name' => 'Samir', 'role' => 'Head Trainer', 'image' => 'samir.jpg'],
            ['name' => 'Mahima', 'role' => 'Community Manager', 'image' => 'mahima.jpg']
        ];

        foreach ($teamMembers as $member) {
            echo '<div class="team-member">';
            echo '<img src="' . $member['image'] . '" alt="' . $member['name'] . '">';
            echo '<h3>' . $member['name'] . '</h3>';
            echo '<p>' . $member['role'] . '</p>';
            echo '</div>';
        }
        ?>
    </div>
</section>

<footer>
    <p>Contact us: team@corflex.com | Student Project by Oscar, Samir & Mahima</p>
    <p>&copy; 2023 Corflex Gym. All rights reserved.</p>
</footer>

</body>
</html>